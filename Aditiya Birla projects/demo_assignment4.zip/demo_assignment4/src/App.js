import React,{useState,useEffect} from 'react';

import './App.css';

function App() {
  
  const [items,setItems] = useState([]);
  const [inputValue, setInputValue] = useState([]);

  const [dropdown,setDropDown] = useState();
  


  useEffect(()=>{
    console.log('render');
    fetch(`http://localhost:5000/policy`)
    .then(response => response.json())
    .then(json => setItems(json))
    .catch(err =>{console.log(err)});
  },[])

  
  

  return (
    <div className="App">
      <label>Select the Financial Year</label>
      <input type="text" placeholder="Select the Financial Year" value={inputValue}/>
      <select name="years" id="years">
        {inputValue.map((item)=>{
          return(
            <option value={item}>{item}</option>
          )
        })}
      </select>
      <br/>
      <br/>

      {
      items.map((item)=>{
        const month = item.policy_issuance_date.split("/")[1]
        const year = item.policy_issuance_date.split("/")[2]
        let financialYear = parseInt(year,10);
        let financialYearArray = [];
        if(month>=4){
          financialYearArray = [`${financialYear} - ${financialYear+1}`]
        }else{
          financialYearArray = [`${financialYear-1} - ${financialYear}`,`${financialYear} - ${financialYear+1}`]
        }
        return(
          <div>
          <input type="radio"  value={financialYear} name="radioButton" 
          onChange={(e)=>{
            setInputValue(financialYearArray);
            

          
          }}/>
          <b>{item.policy_name}</b>
        </div>
        )
        
      })
      }
    </div>
  );
}

export default App;
